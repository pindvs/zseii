<?php
$price = 199;
$name = "Kurs PHP";
echo $name;
?>