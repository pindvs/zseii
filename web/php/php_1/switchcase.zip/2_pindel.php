<?php
//2
$basic_price = 199;
$name = "Kurs PHP";
echo $name;
//3
$price = 229.99;
echo $price;
//4
//komentarz
//5
$price = 899;
$symbol = zł;
echo "Cena: " . $price . $symbol;
//cudzyslow i apostrof
?>